<?php

class Klant{

    public $Naam;
    public $Adres;
    public $Email;
    public $Aankoop;

}

class Auto{

    public $Eigenaar;
    public $Model;
    public $Kleur;
    public $LaatsteApk;
}


$Persoon1 = new Klant ();
$Persoon1-> Naam = 'Bob';
$Persoon1-> Adres = 'Huis 12';
$Persoon1-> Email = 'Mail@Mail.com';
$Persoon1-> Aankoop = 'Lada Niva';

$Auto1 = new Auto ();
$Auto1-> Eigenaar = 'Bob';
$Auto1-> Model = 'Lada Niva';
$Auto1-> Kleur = 'Wit';
$Auto1-> LaatsteApk = '06/02/1947';

var_dump($Persoon1);
var_dump($Auto1);


